This folder contains the code to create a real time application with React, Angular, Vue and socket.io with NodeJS.
Angular version is 12 and node is built with express framework. Socket.io version is v4
To read about the article you can follow the article link at my website.
PART 2 code is available on this branch: https://github.com/deepinder10/socketio-example/tree/PART-2

React:
https://deepinder.me/creating-a-real-time-chat-application-with-angular-and-socket-io-with-nodejs/

Angular:
https://deepinder.me/creating-a-real-time-app-with-angular-8-and-socket-io-with-nodejs/

Vue:
https://deepinder.me/creating-a-real-time-chat-app-with-vue-socket-io-and-nodejs/
